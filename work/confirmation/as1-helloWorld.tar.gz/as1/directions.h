#ifndef DIRECTIONS_H
#define DIRECTIONS_H

typedef enum {LEFT, RIGHT, UP, DOWN, INVALID} directions;

#endif